﻿namespace Facebook
{
    partial class profilepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation1 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(profilepage));
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.profilepicpanel = new System.Windows.Forms.Panel();
            this.profilebtn = new System.Windows.Forms.Label();
            this.Profilpic = new System.Windows.Forms.PictureBox();
            this.friendsbtn = new System.Windows.Forms.Button();
            this.homebtn = new System.Windows.Forms.Button();
            this.settingsbtn = new System.Windows.Forms.Button();
            this.notificationbtn = new System.Windows.Forms.Button();
            this.messagesbtn = new System.Windows.Forms.Button();
            this.searchbtn = new System.Windows.Forms.Button();
            this.searchtxt = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.titlepar = new System.Windows.Forms.Panel();
            this.minimizebtn = new System.Windows.Forms.Button();
            this.maxmizebtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.posts_place = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.postbtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.privacybtn = new System.Windows.Forms.Button();
            this.tagbtn = new System.Windows.Forms.Button();
            this.posttxt = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuTransition1 = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.cover_profile_photo1 = new Facebook.cover_profile_photo();
            this.chat2 = new Facebook.UserControls.chat();
            this.panel2.SuspendLayout();
            this.profilepicpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Profilpic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.titlepar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.posts_place.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Controls.Add(this.profilepicpanel);
            this.panel2.Controls.Add(this.friendsbtn);
            this.panel2.Controls.Add(this.homebtn);
            this.panel2.Controls.Add(this.settingsbtn);
            this.panel2.Controls.Add(this.notificationbtn);
            this.panel2.Controls.Add(this.messagesbtn);
            this.panel2.Controls.Add(this.searchbtn);
            this.panel2.Controls.Add(this.searchtxt);
            this.panel2.Controls.Add(this.pictureBox1);
            this.bunifuTransition1.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(954, 45);
            this.panel2.TabIndex = 20;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.bunifuTransition1.SetDecoration(this.tableLayoutPanel3, BunifuAnimatorNS.DecorationType.None);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(57, 54);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(662, 355);
            this.tableLayoutPanel3.TabIndex = 17;
            // 
            // profilepicpanel
            // 
            this.profilepicpanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.profilepicpanel.Controls.Add(this.profilebtn);
            this.profilepicpanel.Controls.Add(this.Profilpic);
            this.bunifuTransition1.SetDecoration(this.profilepicpanel, BunifuAnimatorNS.DecorationType.None);
            this.profilepicpanel.Location = new System.Drawing.Point(478, 11);
            this.profilepicpanel.Name = "profilepicpanel";
            this.profilepicpanel.Size = new System.Drawing.Size(91, 27);
            this.profilepicpanel.TabIndex = 16;
            // 
            // profilebtn
            // 
            this.profilebtn.AutoSize = true;
            this.profilebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.profilebtn, BunifuAnimatorNS.DecorationType.None);
            this.profilebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.profilebtn.ForeColor = System.Drawing.Color.White;
            this.profilebtn.Location = new System.Drawing.Point(38, 7);
            this.profilebtn.Name = "profilebtn";
            this.profilebtn.Size = new System.Drawing.Size(49, 15);
            this.profilebtn.TabIndex = 17;
            this.profilebtn.Text = "Profile";
            this.profilebtn.Click += new System.EventHandler(this.profilebtn_Click);
            // 
            // Profilpic
            // 
            this.Profilpic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.Profilpic, BunifuAnimatorNS.DecorationType.None);
            this.Profilpic.Image = global::Facebook.Properties.Resources.man_2_icon;
            this.Profilpic.Location = new System.Drawing.Point(3, -4);
            this.Profilpic.Name = "Profilpic";
            this.Profilpic.Size = new System.Drawing.Size(30, 32);
            this.Profilpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Profilpic.TabIndex = 16;
            this.Profilpic.TabStop = false;
            this.Profilpic.Click += new System.EventHandler(this.Profilpic_Click);
            // 
            // friendsbtn
            // 
            this.friendsbtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.friendsbtn.BackColor = System.Drawing.Color.Transparent;
            this.friendsbtn.BackgroundImage = global::Facebook.Properties.Resources.frinds1;
            this.friendsbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.friendsbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.friendsbtn, BunifuAnimatorNS.DecorationType.None);
            this.friendsbtn.FlatAppearance.BorderSize = 0;
            this.friendsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.friendsbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.friendsbtn.Location = new System.Drawing.Point(739, 3);
            this.friendsbtn.Name = "friendsbtn";
            this.friendsbtn.Size = new System.Drawing.Size(29, 40);
            this.friendsbtn.TabIndex = 12;
            this.friendsbtn.UseVisualStyleBackColor = false;
            // 
            // homebtn
            // 
            this.homebtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.homebtn.BackColor = System.Drawing.Color.Transparent;
            this.homebtn.BackgroundImage = global::Facebook.Properties.Resources.Home_2_icon;
            this.homebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.homebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.homebtn, BunifuAnimatorNS.DecorationType.None);
            this.homebtn.FlatAppearance.BorderSize = 0;
            this.homebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homebtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.homebtn.Location = new System.Drawing.Point(595, 11);
            this.homebtn.Name = "homebtn";
            this.homebtn.Size = new System.Drawing.Size(73, 27);
            this.homebtn.TabIndex = 14;
            this.homebtn.Text = "Home";
            this.homebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.homebtn.UseVisualStyleBackColor = false;
            this.homebtn.Click += new System.EventHandler(this.homebtn_Click);
            // 
            // settingsbtn
            // 
            this.settingsbtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.settingsbtn.BackColor = System.Drawing.Color.Transparent;
            this.settingsbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.settingsbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.settingsbtn, BunifuAnimatorNS.DecorationType.None);
            this.settingsbtn.FlatAppearance.BorderSize = 0;
            this.settingsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.settingsbtn.ForeColor = System.Drawing.Color.White;
            this.settingsbtn.Location = new System.Drawing.Point(873, 3);
            this.settingsbtn.Name = "settingsbtn";
            this.settingsbtn.Size = new System.Drawing.Size(72, 40);
            this.settingsbtn.TabIndex = 13;
            this.settingsbtn.Text = "Sign Out";
            this.settingsbtn.UseVisualStyleBackColor = false;
            this.settingsbtn.Click += new System.EventHandler(this.settingsbtn_Click);
            // 
            // notificationbtn
            // 
            this.notificationbtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.notificationbtn.BackColor = System.Drawing.Color.Transparent;
            this.notificationbtn.BackgroundImage = global::Facebook.Properties.Resources.notifecations1;
            this.notificationbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.notificationbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.notificationbtn, BunifuAnimatorNS.DecorationType.None);
            this.notificationbtn.FlatAppearance.BorderSize = 0;
            this.notificationbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.notificationbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notificationbtn.Location = new System.Drawing.Point(823, 3);
            this.notificationbtn.Name = "notificationbtn";
            this.notificationbtn.Size = new System.Drawing.Size(29, 40);
            this.notificationbtn.TabIndex = 11;
            this.notificationbtn.UseVisualStyleBackColor = false;
            // 
            // messagesbtn
            // 
            this.messagesbtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.messagesbtn.BackColor = System.Drawing.Color.Transparent;
            this.messagesbtn.BackgroundImage = global::Facebook.Properties.Resources.messages1;
            this.messagesbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.messagesbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.messagesbtn, BunifuAnimatorNS.DecorationType.None);
            this.messagesbtn.FlatAppearance.BorderSize = 0;
            this.messagesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.messagesbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.messagesbtn.Location = new System.Drawing.Point(782, 3);
            this.messagesbtn.Name = "messagesbtn";
            this.messagesbtn.Size = new System.Drawing.Size(29, 40);
            this.messagesbtn.TabIndex = 10;
            this.messagesbtn.UseVisualStyleBackColor = false;
            // 
            // searchbtn
            // 
            this.searchbtn.BackColor = System.Drawing.Color.White;
            this.searchbtn.BackgroundImage = global::Facebook.Properties.Resources.search;
            this.searchbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.searchbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.searchbtn, BunifuAnimatorNS.DecorationType.None);
            this.searchbtn.FlatAppearance.BorderSize = 0;
            this.searchbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchbtn.Location = new System.Drawing.Point(371, 11);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(26, 21);
            this.searchbtn.TabIndex = 8;
            this.searchbtn.UseVisualStyleBackColor = false;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // searchtxt
            // 
            this.bunifuTransition1.SetDecoration(this.searchtxt, BunifuAnimatorNS.DecorationType.None);
            this.searchtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchtxt.ForeColor = System.Drawing.Color.Silver;
            this.searchtxt.Location = new System.Drawing.Point(83, 8);
            this.searchtxt.Name = "searchtxt";
            this.searchtxt.Size = new System.Drawing.Size(317, 24);
            this.searchtxt.TabIndex = 9;
            this.searchtxt.Text = "Search";
            this.searchtxt.Enter += new System.EventHandler(this.searchtxt_Enter);
            this.searchtxt.Leave += new System.EventHandler(this.searchtxt_Leave);
            // 
            // pictureBox1
            // 
            this.bunifuTransition1.SetDecoration(this.pictureBox1, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(45, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(21, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // titlepar
            // 
            this.titlepar.AutoSize = true;
            this.titlepar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(153)))));
            this.titlepar.Controls.Add(this.minimizebtn);
            this.titlepar.Controls.Add(this.maxmizebtn);
            this.titlepar.Controls.Add(this.Exitbtn);
            this.titlepar.Controls.Add(this.pictureBox2);
            this.titlepar.Controls.Add(this.label1);
            this.bunifuTransition1.SetDecoration(this.titlepar, BunifuAnimatorNS.DecorationType.None);
            this.titlepar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepar.Location = new System.Drawing.Point(0, 0);
            this.titlepar.Name = "titlepar";
            this.titlepar.Size = new System.Drawing.Size(954, 27);
            this.titlepar.TabIndex = 19;
            this.titlepar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.titlepar_MouseDown_2);
            this.titlepar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.titlepar_MouseMove_2);
            this.titlepar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.titlepar_MouseUp_1);
            // 
            // minimizebtn
            // 
            this.minimizebtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bunifuTransition1.SetDecoration(this.minimizebtn, BunifuAnimatorNS.DecorationType.None);
            this.minimizebtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimizebtn.FlatAppearance.BorderSize = 0;
            this.minimizebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimizebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.minimizebtn.ForeColor = System.Drawing.Color.White;
            this.minimizebtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.minimizebtn.Location = new System.Drawing.Point(873, 0);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.Size = new System.Drawing.Size(27, 27);
            this.minimizebtn.TabIndex = 9;
            this.minimizebtn.Text = "-";
            this.minimizebtn.UseVisualStyleBackColor = false;
            this.minimizebtn.Click += new System.EventHandler(this.minimizebtn_Click);
            // 
            // maxmizebtn
            // 
            this.maxmizebtn.BackColor = System.Drawing.Color.Transparent;
            this.maxmizebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bunifuTransition1.SetDecoration(this.maxmizebtn, BunifuAnimatorNS.DecorationType.None);
            this.maxmizebtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.maxmizebtn.FlatAppearance.BorderSize = 0;
            this.maxmizebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxmizebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.maxmizebtn.ForeColor = System.Drawing.Color.White;
            this.maxmizebtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.maxmizebtn.Location = new System.Drawing.Point(900, 0);
            this.maxmizebtn.Name = "maxmizebtn";
            this.maxmizebtn.Size = new System.Drawing.Size(27, 27);
            this.maxmizebtn.TabIndex = 8;
            this.maxmizebtn.Text = "+";
            this.maxmizebtn.UseVisualStyleBackColor = false;
            this.maxmizebtn.Click += new System.EventHandler(this.maximizbtn_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.BackColor = System.Drawing.Color.Transparent;
            this.Exitbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bunifuTransition1.SetDecoration(this.Exitbtn, BunifuAnimatorNS.DecorationType.None);
            this.Exitbtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.Exitbtn.FlatAppearance.BorderSize = 0;
            this.Exitbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Exitbtn.Image = ((System.Drawing.Image)(resources.GetObject("Exitbtn.Image")));
            this.Exitbtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Exitbtn.Location = new System.Drawing.Point(927, 0);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(27, 27);
            this.Exitbtn.TabIndex = 7;
            this.Exitbtn.UseVisualStyleBackColor = false;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click_1);
            // 
            // pictureBox2
            // 
            this.bunifuTransition1.SetDecoration(this.pictureBox2, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(16, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(19, 19);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label1, BunifuAnimatorNS.DecorationType.None);
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(41, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(320, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Facebook - Your Distinct Way To Connect the World!";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.bunifuTransition1.SetDecoration(this.tableLayoutPanel1, BunifuAnimatorNS.DecorationType.None);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.tableLayoutPanel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 76F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 534F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(960, 629);
            this.tableLayoutPanel1.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.titlepar);
            this.bunifuTransition1.SetDecoration(this.panel1, BunifuAnimatorNS.DecorationType.None);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(954, 70);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.878151F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 92.12185F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 219F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.chat2, 2, 0);
            this.bunifuTransition1.SetDecoration(this.tableLayoutPanel2, BunifuAnimatorNS.DecorationType.None);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 79);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(954, 547);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.cover_profile_photo1, 0, 0);
            this.bunifuTransition1.SetDecoration(this.tableLayoutPanel4, BunifuAnimatorNS.DecorationType.None);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(60, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 279F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(671, 521);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.AutoSize = true;
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 272F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 415F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Controls.Add(this.posts_place, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.panel5, 0, 0);
            this.bunifuTransition1.SetDecoration(this.tableLayoutPanel5, BunifuAnimatorNS.DecorationType.None);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 282);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(665, 236);
            this.tableLayoutPanel5.TabIndex = 1;
            this.tableLayoutPanel5.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel5_Paint);
            // 
            // posts_place
            // 
            this.posts_place.AutoScroll = true;
            this.posts_place.Controls.Add(this.panel3);
            this.bunifuTransition1.SetDecoration(this.posts_place, BunifuAnimatorNS.DecorationType.None);
            this.posts_place.Location = new System.Drawing.Point(275, 3);
            this.posts_place.Name = "posts_place";
            this.posts_place.Size = new System.Drawing.Size(409, 230);
            this.posts_place.TabIndex = 18;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.posttxt);
            this.bunifuTransition1.SetDecoration(this.panel3, BunifuAnimatorNS.DecorationType.None);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(507, 187);
            this.panel3.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.button1);
            this.panel4.Controls.Add(this.postbtn);
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.privacybtn);
            this.panel4.Controls.Add(this.tagbtn);
            this.bunifuTransition1.SetDecoration(this.panel4, BunifuAnimatorNS.DecorationType.None);
            this.panel4.Location = new System.Drawing.Point(0, 149);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(392, 38);
            this.panel4.TabIndex = 1;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.button3, BunifuAnimatorNS.DecorationType.None);
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Image = global::Facebook.Properties.Resources.Emotes_face_smile_icon;
            this.button3.Location = new System.Drawing.Point(222, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(33, 32);
            this.button3.TabIndex = 14;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.button1, BunifuAnimatorNS.DecorationType.None);
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Image = global::Facebook.Properties.Resources.camera_icon;
            this.button1.Location = new System.Drawing.Point(132, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 32);
            this.button1.TabIndex = 12;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // postbtn
            // 
            this.postbtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.postbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.postbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.postbtn, BunifuAnimatorNS.DecorationType.None);
            this.postbtn.FlatAppearance.BorderSize = 0;
            this.postbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.postbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.postbtn.Location = new System.Drawing.Point(283, 4);
            this.postbtn.Name = "postbtn";
            this.postbtn.Size = new System.Drawing.Size(106, 32);
            this.postbtn.TabIndex = 11;
            this.postbtn.Text = "post";
            this.postbtn.UseVisualStyleBackColor = false;
            this.postbtn.Click += new System.EventHandler(this.postbtn_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.button2, BunifuAnimatorNS.DecorationType.None);
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Image = global::Facebook.Properties.Resources.video_camera_icon;
            this.button2.Location = new System.Drawing.Point(177, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(33, 32);
            this.button2.TabIndex = 13;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // privacybtn
            // 
            this.privacybtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.privacybtn.BackColor = System.Drawing.Color.White;
            this.privacybtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.privacybtn, BunifuAnimatorNS.DecorationType.None);
            this.privacybtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.privacybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.privacybtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.privacybtn.ForeColor = System.Drawing.Color.Gray;
            this.privacybtn.Image = global::Facebook.Properties.Resources.publi;
            this.privacybtn.Location = new System.Drawing.Point(4, 3);
            this.privacybtn.Name = "privacybtn";
            this.privacybtn.Size = new System.Drawing.Size(75, 32);
            this.privacybtn.TabIndex = 10;
            this.privacybtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.privacybtn.UseVisualStyleBackColor = false;
            // 
            // tagbtn
            // 
            this.tagbtn.BackColor = System.Drawing.Color.White;
            this.tagbtn.BackgroundImage = global::Facebook.Properties.Resources.tagmini;
            this.tagbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tagbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.tagbtn, BunifuAnimatorNS.DecorationType.None);
            this.tagbtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tagbtn.FlatAppearance.BorderSize = 0;
            this.tagbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tagbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tagbtn.ForeColor = System.Drawing.Color.Gray;
            this.tagbtn.Location = new System.Drawing.Point(92, 5);
            this.tagbtn.Name = "tagbtn";
            this.tagbtn.Size = new System.Drawing.Size(33, 32);
            this.tagbtn.TabIndex = 9;
            this.tagbtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tagbtn.UseVisualStyleBackColor = false;
            // 
            // posttxt
            // 
            this.posttxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuTransition1.SetDecoration(this.posttxt, BunifuAnimatorNS.DecorationType.None);
            this.posttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posttxt.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.posttxt.Location = new System.Drawing.Point(0, 0);
            this.posttxt.Multiline = true;
            this.posttxt.Name = "posttxt";
            this.posttxt.Size = new System.Drawing.Size(389, 143);
            this.posttxt.TabIndex = 0;
            this.posttxt.Text = "What\'s on your mind ?";
            this.posttxt.TextChanged += new System.EventHandler(this.posttxt_TextChanged);
            this.posttxt.Enter += new System.EventHandler(this.posttxt_Enter);
            this.posttxt.Leave += new System.EventHandler(this.posttxt_Leave);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.textBox1);
            this.panel5.Controls.Add(this.linkLabel1);
            this.panel5.Controls.Add(this.label2);
            this.bunifuTransition1.SetDecoration(this.panel5, BunifuAnimatorNS.DecorationType.None);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(266, 230);
            this.panel5.TabIndex = 19;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.bunifuTransition1.SetDecoration(this.panel9, BunifuAnimatorNS.DecorationType.None);
            this.panel9.Location = new System.Drawing.Point(3, 14);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(10, 210);
            this.panel9.TabIndex = 28;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.bunifuTransition1.SetDecoration(this.panel8, BunifuAnimatorNS.DecorationType.None);
            this.panel8.Location = new System.Drawing.Point(253, 13);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 211);
            this.panel8.TabIndex = 27;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.bunifuTransition1.SetDecoration(this.panel7, BunifuAnimatorNS.DecorationType.None);
            this.panel7.Location = new System.Drawing.Point(3, 216);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(260, 11);
            this.panel7.TabIndex = 26;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.bunifuTransition1.SetDecoration(this.panel6, BunifuAnimatorNS.DecorationType.None);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(260, 11);
            this.panel6.TabIndex = 25;
            // 
            // textBox1
            // 
            this.bunifuTransition1.SetDecoration(this.textBox1, BunifuAnimatorNS.DecorationType.None);
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 33);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(248, 188);
            this.textBox1.TabIndex = 24;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_2);
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.Red;
            this.bunifuTransition1.SetDecoration(this.linkLabel1, BunifuAnimatorNS.DecorationType.None);
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(118, 17);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(33, 13);
            this.linkLabel1.TabIndex = 23;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Edit";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.Red;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.bunifuTransition1.SetDecoration(this.label2, BunifuAnimatorNS.DecorationType.None);
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.label2.Location = new System.Drawing.Point(16, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 18);
            this.label2.TabIndex = 20;
            this.label2.Text = "Bio:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 25;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuTransition1
            // 
            this.bunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.VertSlide;
            this.bunifuTransition1.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.bunifuTransition1.DefaultAnimation = animation1;
            // 
            // cover_profile_photo1
            // 
            this.cover_profile_photo1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.bunifuTransition1.SetDecoration(this.cover_profile_photo1, BunifuAnimatorNS.DecorationType.None);
            this.cover_profile_photo1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cover_profile_photo1.Location = new System.Drawing.Point(3, 3);
            this.cover_profile_photo1.Name = "cover_profile_photo1";
            this.cover_profile_photo1.Size = new System.Drawing.Size(665, 273);
            this.cover_profile_photo1.TabIndex = 15;
            this.cover_profile_photo1.Load += new System.EventHandler(this.cover_profile_photo1_Load);
            // 
            // chat2
            // 
            this.chat2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.chat2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.bunifuTransition1.SetDecoration(this.chat2, BunifuAnimatorNS.DecorationType.None);
            this.chat2.Location = new System.Drawing.Point(770, 138);
            this.chat2.Name = "chat2";
            this.chat2.Size = new System.Drawing.Size(181, 386);
            this.chat2.TabIndex = 1;
            // 
            // profilepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(960, 629);
            this.Controls.Add(this.tableLayoutPanel1);
            this.bunifuTransition1.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "profilepage";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.profilepage_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.profilepicpanel.ResumeLayout(false);
            this.profilepicpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Profilpic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.titlepar.ResumeLayout(false);
            this.titlepar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.posts_place.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button friendsbtn;
        private System.Windows.Forms.Button homebtn;
        private System.Windows.Forms.Button settingsbtn;
        private System.Windows.Forms.Button notificationbtn;
        private System.Windows.Forms.Button messagesbtn;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.TextBox searchtxt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel titlepar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel profilepicpanel;
        private System.Windows.Forms.Label profilebtn;
        private System.Windows.Forms.PictureBox Profilpic;
        private System.Windows.Forms.Button minimizebtn;
        private System.Windows.Forms.Button maxmizebtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private BunifuAnimatorNS.BunifuTransition bunifuTransition1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private UserControls.chat chat2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private cover_profile_photo cover_profile_photo1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox posttxt;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button postbtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button privacybtn;
        private System.Windows.Forms.Button tagbtn;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.FlowLayoutPanel posts_place;

        public bool Win { get; set; }
    }
}