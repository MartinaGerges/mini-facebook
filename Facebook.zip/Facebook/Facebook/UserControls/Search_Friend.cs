﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Facebook.UserControls
{
    public partial class Search_Friend : UserControl
    {
        public Search_Friend()
        {
            InitializeComponent();
        }
    }
}
