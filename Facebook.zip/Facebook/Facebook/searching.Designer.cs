﻿namespace Facebook
{
    partial class searching
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(searching));
            this.titlepar = new System.Windows.Forms.Panel();
            this.minimizebtn = new System.Windows.Forms.Button();
            this.maxmizebtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.searchevent = new System.Windows.Forms.Button();
            this.searchtxt = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.titlepar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // titlepar
            // 
            this.titlepar.AutoSize = true;
            this.titlepar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(153)))));
            this.titlepar.Controls.Add(this.minimizebtn);
            this.titlepar.Controls.Add(this.maxmizebtn);
            this.titlepar.Controls.Add(this.Exitbtn);
            this.titlepar.Controls.Add(this.pictureBox2);
            this.titlepar.Controls.Add(this.label1);
            this.titlepar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepar.Location = new System.Drawing.Point(0, 0);
            this.titlepar.Name = "titlepar";
            this.titlepar.Size = new System.Drawing.Size(518, 27);
            this.titlepar.TabIndex = 22;
            this.titlepar.Paint += new System.Windows.Forms.PaintEventHandler(this.titlepar_Paint);
            this.titlepar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.titlepar_MouseDown);
            this.titlepar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.titlepar_MouseMove);
            // 
            // minimizebtn
            // 
            this.minimizebtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.minimizebtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimizebtn.FlatAppearance.BorderSize = 0;
            this.minimizebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimizebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.minimizebtn.ForeColor = System.Drawing.Color.White;
            this.minimizebtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.minimizebtn.Location = new System.Drawing.Point(437, 0);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.Size = new System.Drawing.Size(27, 27);
            this.minimizebtn.TabIndex = 9;
            this.minimizebtn.Text = "-";
            this.minimizebtn.UseVisualStyleBackColor = false;
            // 
            // maxmizebtn
            // 
            this.maxmizebtn.BackColor = System.Drawing.Color.Transparent;
            this.maxmizebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.maxmizebtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.maxmizebtn.FlatAppearance.BorderSize = 0;
            this.maxmizebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maxmizebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.maxmizebtn.ForeColor = System.Drawing.Color.White;
            this.maxmizebtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.maxmizebtn.Location = new System.Drawing.Point(464, 0);
            this.maxmizebtn.Name = "maxmizebtn";
            this.maxmizebtn.Size = new System.Drawing.Size(27, 27);
            this.maxmizebtn.TabIndex = 8;
            this.maxmizebtn.Text = "+";
            this.maxmizebtn.UseVisualStyleBackColor = false;
            // 
            // Exitbtn
            // 
            this.Exitbtn.BackColor = System.Drawing.Color.Transparent;
            this.Exitbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Exitbtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.Exitbtn.FlatAppearance.BorderSize = 0;
            this.Exitbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Exitbtn.Image = ((System.Drawing.Image)(resources.GetObject("Exitbtn.Image")));
            this.Exitbtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Exitbtn.Location = new System.Drawing.Point(491, 0);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(27, 27);
            this.Exitbtn.TabIndex = 7;
            this.Exitbtn.UseVisualStyleBackColor = false;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.Location = new System.Drawing.Point(16, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(19, 19);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(41, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(320, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Facebook - Your Distinct Way To Connect the World!";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 61);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(491, 344);
            this.flowLayoutPanel1.TabIndex = 25;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(103)))), ((int)(((byte)(178)))));
            this.panel2.Controls.Add(this.searchevent);
            this.panel2.Controls.Add(this.searchtxt);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(518, 36);
            this.panel2.TabIndex = 24;
            // 
            // searchevent
            // 
            this.searchevent.BackColor = System.Drawing.Color.White;
            this.searchevent.BackgroundImage = global::Facebook.Properties.Resources.search;
            this.searchevent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.searchevent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.searchevent.FlatAppearance.BorderSize = 0;
            this.searchevent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchevent.Location = new System.Drawing.Point(283, 6);
            this.searchevent.Name = "searchevent";
            this.searchevent.Size = new System.Drawing.Size(26, 21);
            this.searchevent.TabIndex = 10;
            this.searchevent.UseVisualStyleBackColor = false;
            this.searchevent.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // searchtxt
            // 
            this.searchtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchtxt.ForeColor = System.Drawing.Color.Silver;
            this.searchtxt.Location = new System.Drawing.Point(66, 4);
            this.searchtxt.Name = "searchtxt";
            this.searchtxt.Size = new System.Drawing.Size(247, 24);
            this.searchtxt.TabIndex = 9;
            this.searchtxt.Text = "Search";
            this.searchtxt.TextChanged += new System.EventHandler(this.searchtxt_TextChanged);
            this.searchtxt.Enter += new System.EventHandler(this.searchtxt_Enter);
            this.searchtxt.Leave += new System.EventHandler(this.searchtxt_Leave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(39, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(21, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // searching
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 403);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.titlepar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "searching";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "searching";
            this.Load += new System.EventHandler(this.searching_Load);
            this.titlepar.ResumeLayout(false);
            this.titlepar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel titlepar;
        private System.Windows.Forms.Button minimizebtn;
        private System.Windows.Forms.Button maxmizebtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button searchevent;
        private System.Windows.Forms.TextBox searchtxt;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}